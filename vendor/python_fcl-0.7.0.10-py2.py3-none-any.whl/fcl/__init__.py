"""Stub python-fcl for ARM64 Linux.

Implements the full surface area used by Scenic 3's collision checking so that
Scenic's import chain works and scene generation does not crash on the broad-
phase collision manager.  The stubs never report any collisions — our LIBERO
Scenic programs use explicit `require distance > threshold` constraints for
clearance, not FCL geometry intersection.
"""

import numpy as np


class Transform:
    def __init__(self, R=None, T=None):
        self.R = R if R is not None else np.eye(3)
        self.T = T if T is not None else np.zeros(3)


class CollisionGeometry:
    pass


class Box(CollisionGeometry):
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z


class Sphere(CollisionGeometry):
    def __init__(self, radius):
        self.radius = radius


class Cylinder(CollisionGeometry):
    def __init__(self, radius, lz):
        self.radius, self.lz = radius, lz


class Cone(CollisionGeometry):
    def __init__(self, radius, lz):
        self.radius, self.lz = radius, lz


class Convex(CollisionGeometry):
    def __init__(self, vertices, faces):
        self.vertices, self.faces = vertices, faces


class BVHModel(CollisionGeometry):
    def __init__(self):
        self._vertices = []
        self._faces = []

    def beginModel(self, n_faces=0, n_vertices=0):
        pass

    def addSubModel(self, vertices, faces):
        self._vertices = vertices
        self._faces = faces

    def endModel(self):
        pass


class CollisionObject:
    def __init__(self, geometry, transform=None):
        self.geometry = geometry
        self.transform = transform or Transform()
        self._data = None

    def getTranslation(self):
        return self.transform.T

    def getRotation(self):
        return self.transform.R

    def setTranslation(self, T):
        self.transform.T = T

    def setRotation(self, R):
        self.transform.R = R

    def computeAABB(self):
        pass


class CollisionResult:
    def __init__(self):
        self.is_collision = False
        self.contacts = []

    def isCollision(self):
        return self.is_collision


class CollisionRequest:
    def __init__(self, num_max_contacts=1, enable_contact=False):
        self.num_max_contacts = num_max_contacts
        self.enable_contact = enable_contact


class CollisionData:
    def __init__(self, request=None, result=None):
        self.request = request or CollisionRequest()
        self.result = result or CollisionResult()
        self.done = False


class BroadPhaseCollisionManager:
    def __init__(self):
        self._objects = []

    def registerObject(self, obj):
        self._objects.append(obj)

    def setup(self):
        pass

    def update(self, obj=None):
        pass

    def collide(self, callback, data):
        pass

    def clear(self):
        self._objects.clear()


class DynamicAABBTreeCollisionManager(BroadPhaseCollisionManager):
    """Broad-phase collision manager used by Scenic's requirement checker.

    Stub: always reports no collisions.  Our programs use explicit distance
    constraints instead of FCL geometry intersection.
    """
    pass


class SSVMCollisionManager(BroadPhaseCollisionManager):
    pass


class SAPCollisionManager(BroadPhaseCollisionManager):
    pass


def defaultCollisionCallback(obj1, obj2, data):
    data.done = False
    return False


def collide(obj1, obj2, request=None, result=None):
    if result is not None:
        result.is_collision = False
    return 0


def distance(obj1, obj2, request=None, result=None):
    return 999.0
